package observer;

public class RSSFeed implements Observer {

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

}
