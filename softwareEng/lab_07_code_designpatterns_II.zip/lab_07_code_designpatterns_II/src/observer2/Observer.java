package observer2;

import java.util.Date;

public interface Observer {
	public void update(Date time);
}
