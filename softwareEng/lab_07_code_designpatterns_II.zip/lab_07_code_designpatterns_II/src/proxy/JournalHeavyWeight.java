package proxy;

public class JournalHeavyWeight implements Journal {
	
	public String getTitle() {
		//  Get a title from Journal stored in a database.
		return null;
	}

	public void setTitle(String title) {
		//  Set a title from Journal stored in a database.
		
	}
	
	public String getEditor() {
		//  Get editor from Journal stored in a database.
		return null;
	}

	public void setEditor(String editor) {
		//  Set editor from Journal stored in a database.
		
	}
	
	//  ETC for remaining getters/settings
	public String getPublicationDate() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void setPublicationDate(String publicationDate) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int getISBN() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void setISBN(int ISBN) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int getPages() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void setPages(int pages) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String getSummmary() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void setSummary(String summary) {
		// TODO Auto-generated method stub
		
	}

}
