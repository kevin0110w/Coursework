public class Course
{
    public String shortCode;
    public String name;
    public int credits;

    public Course()
    {
    }

    public Course(String sc, String n, int c)
    {
        shortCode = sc;
        name = n;
        credits = c;
    }
}
